# AI model interaction
