# Script to export tips to PDF
